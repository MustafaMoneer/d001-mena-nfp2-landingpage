# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

This Landing page is a fully dynamic web page built and manipulated with JavaScript and the DOM.

It's part of the Udacity Front-end programming Nanodegree program's assignments.

## Specifications

1. app.js is the main js file.

2. 5 sections of the body content included on the HTML.

3. Navigation menu built dynamically with the DOM.

4. The section in view are distinguished by using functionality to listen to events for sections became active.

5. functionality to smoothly scroll to sections is added.

## Notes
Some functions are not correctly running, so I block comment it for further insights and debugging.

## Credits
Mustafa Moneer
